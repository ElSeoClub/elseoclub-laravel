<div>
    <label class="inline-flex items-center mt-3">
        <input type="radio" value="<?php echo e($value); ?>" class="form-radio h-5 w-5 text-<?php echo e($color); ?>-600" name="<?php echo e($name); ?>"
            <?php echo e($checked != null ? 'checked':''); ?> <?php echo e($model != null ? 'wire:model='.$model:''); ?>><span
            class="ml-2 text-gray-700"><?php echo e($slot); ?></span>
    </label>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/radio.blade.php ENDPATH**/ ?>