<div class="p-2">
    <?php if($location): ?>
    <div class="text-left">
        <p class="text-xl">Trabajador: <span class="text-yellow-600 font-bold"><?php echo e($user->name); ?></span></p>
        <p class="text-xl">Dirección: <span class="text-yellow-600 font-bold"><?php echo e($user_location->description); ?></span></p>
        <p class="text-xl">Fecha de la votación: <span class="text-yellow-600 font-bold">01/12/2021</span>
        </p>
        <p class="text-xl">Horario de votación: <span
                class="text-yellow-600 font-bold"><?php echo e($user_location->schedule); ?></span></p>
    </div>
    <?php if($user_location->georeferences): ?>
    <iframe src="<?php echo e($user_location->georeferences); ?>" width="600" height="450" style="border:0; max-width:100%"
        allowfullscreen="" loading="lazy"></iframe>
    <?php endif; ?>

    <div class="mt-5">
        <?php if($user_location->convocatoria): ?>
        <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['icon' => 'fas fa-download py-3','color' => 'red','href' => Storage::url($user_location->convocatoria),'target' => '_blank']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Descargar
            convocatoria <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <h1 class="text-3xl">Proxima legitimación:</h1>
    <h1 class="text-5xl text-yellow-500 font-bold mb-5">CCT CFE-SUTERM</h1>
    <h1 class="text-3xl">¿Quieres conocer dónde te corresponde votar?</h1>
    <div class="pb-2 pt-4">
        <input type="text" name="username" id="username" placeholder="Ingresa tu clave de empleado"
            value="<?php echo e(old('username')); ?>" class="block w-full p-4 text-lg rounded-sm bg-black" required autofocus
            autocomplete="off" wire:model.defer="username">
    </div>
    <div class="pb-2 pt-4">
        <?php echo $message; ?>

    </div>
    <div class="px-4 pb-2 pt-4">
        <button type="button" wire:click="display_location()"
            class="uppercase block w-full p-4 text-lg rounded-full bg-red-500 hover:bg-red-600 focus:outline-none">Revisar
            sede</button>
    </div>
    <?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/home/location.blade.php ENDPATH**/ ?>