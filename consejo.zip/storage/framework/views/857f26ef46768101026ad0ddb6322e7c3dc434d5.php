<div>
    <li
        class="mt-1 rounded <?php echo e(request()->routeIs($activeRoute) ? 'text-red-600 hover:text-red-700 bg-gray-200 bg-opacity-80':'text-gray-600 hover:text-red-600 hover:bg-gray-100'); ?> ">
        <a href="<?php echo e($route); ?>" class="p-2 flex flex-col items-center" <?php echo e($onclick != null ? 'onclick='.$onclick:'false'); ?>>
            <i class="<?php echo e($icon); ?>"></i>
            <span class="text-xs mt-2 font-bold"><?php echo e($slot); ?></span>
        </a>
    </li>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/layout/general/navigation-menu-option.blade.php ENDPATH**/ ?>