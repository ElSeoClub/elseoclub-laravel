<div>
    <div class="relative z-0 w-full mb-5">
        <input <?php echo e($model != null ? ($defer ? 'wire:model.defer':'wire:model'):''); ?><?php echo e($model != null ? '='.$model:''); ?>

            type="<?php echo e($type); ?>" placeholder=" " autocomplete="off"
            class="pt-3 pb-2 block w-full font-bold px-0 mt-0 bg-transparent border-0 border-b-2 appearance-none focus:outline-none focus:ring-0 focus:border-gray-400 border-gray-200"
            value="<?php echo e($value); ?>" />
        <label for="name" class="absolute duration-300 top-3 -z-1 origin-0 text-gray-500">
            <?php echo e($label); ?>

        </label>
        <?php if($model != null): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => ''.e($model).'']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => ''.e($model).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/input.blade.php ENDPATH**/ ?>