<?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['title' => 'Sedes del evento','px' => '0','py' => '0']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, []); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('thead', null, []); ?> 
            <th class="text-left px-5 py-3">Nombre</th>
            <th class="text-left px-5 py-3"># de invitados</th>
            <th class="text-left px-5 py-3"># de Boletas</th>
            <th class="text-left px-5 py-3">Hora</th>
            <th class="text-left px-5 py-3">Georeferencias</th>
            <th class="text-left px-5 py-3">Convocatoria</th>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('tbody', null, []); ?> 
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover:bg-gray-100">
                <td class="px-5 py-3">
                    <?php if (isset($component)) { $__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\A::class, ['href' => route('legitimation.locations.location',['event' => $event->id,'location'=>$location->id])]); ?>
<?php $component->withName('a'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        <?php echo e($location->name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3)): ?>
<?php $component = $__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3; ?>
<?php unset($__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3); ?>
<?php endif; ?>
                </td>
                <td class="px-5 py-3"><?php echo e($location->guests()->count()); ?></td>
                <td class="px-5 py-3"><?php echo e($location->boletas); ?></td>
                <td class="px-5 py-3"><?php echo e($location->schedule); ?></td>
                <td class="px-5 py-3"><?php echo e($location->georeferences != NULL ? 'SI':'NO'); ?></td>
                <td class="px-5 py-3"><?php echo e($location->convocatoria != NULL ? 'SI':'NO'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/event/legitimation/location/index.blade.php ENDPATH**/ ?>