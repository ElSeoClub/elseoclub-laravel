<div>
    <a <?php echo e($attributes->merge(['class' => "font-bold text-$color-600 hover:text-$color-800 ".$class])); ?> href="<?php echo e($href); ?>"
        <?php echo e($download !== false ? 'download':''); ?> <?php if($target): ?> target="<?php echo e($target); ?>" <?php endif; ?>><?php echo e($slot); ?></a>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/a.blade.php ENDPATH**/ ?>