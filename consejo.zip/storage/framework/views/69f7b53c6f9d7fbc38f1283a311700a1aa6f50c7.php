<div>
    <div class="bg-<?php echo e($color); ?>-100 border-t-4 border-<?php echo e($color); ?>-500 rounded-b text-<?php echo e($color); ?>-900 px-4 py-3 shadow-md mb-5"
        role="alert">
        <div class="flex">
            <div class="py-1"><i class="<?php echo e($icon); ?>"></i></div>
            <div class="ml-5">
                <p class="font-bold"><?php echo e($name); ?></p>
                <p class="text-sm"><?php echo e($slot); ?></p>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/alert.blade.php ENDPATH**/ ?>