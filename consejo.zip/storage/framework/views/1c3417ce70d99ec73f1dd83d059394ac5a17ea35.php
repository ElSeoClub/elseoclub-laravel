<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Sistema de legitimación - Siconecta</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/fontawesome/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

    <?php echo \Livewire\Livewire::styles(); ?>


    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.js')); ?>" defer></script>
</head>

<body class="font-sans antialiased">
    <div class="h-screen w-full flex overflow-hidden">
        <?php if (isset($component)) { $__componentOriginal0afddf248101ff9bfebf26a1afc2cd43b219f4bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\NavigationMenu::class, []); ?>
<?php $component->withName('layout.general.navigation-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0afddf248101ff9bfebf26a1afc2cd43b219f4bd)): ?>
<?php $component = $__componentOriginal0afddf248101ff9bfebf26a1afc2cd43b219f4bd; ?>
<?php unset($__componentOriginal0afddf248101ff9bfebf26a1afc2cd43b219f4bd); ?>
<?php endif; ?>

        <main class="pt-2 pb-2 px-5 flex-1 bg-gray-200 dark:bg-black
                transition duration-500 ease-in-out overflow-y-auto">
            <h1 class="mt-2 text-2xl font-bold"><?php echo e($title); ?></h1>
            <?php echo e($slot); ?>

        </main>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('js/sweetalerts.js')); ?>?v=11"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\consejo\resources\views/layouts/general.blade.php ENDPATH**/ ?>