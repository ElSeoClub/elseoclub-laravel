<?php $attributes = $attributes->exceptProps(['class' => '']); ?>
<?php foreach (array_filter((['class' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <?php if($href != null): ?>
    <a href=<?php echo e($href); ?> target="<?php echo e($target); ?>">
        <button type=" <?php echo e($type); ?>" <?php echo e($click !=null ? 'wire:click=' .$click.'':''); ?> <?php echo e($attributes->merge(['class' =>
            'text-base bg-'.$color.'-500 text-white font-bold px-3 py-1 rounded
            hover:bg-'.$color.'-600 focus:bg-'.$color.'-600 focus:outline-none focus:ring focus:ring-'.$color.'-600
            focus:ring-opacity-50 '.$class])); ?>> <?php if($icon !=null): ?> <i class="<?php echo e($icon); ?> mr-2"></i>
            <?php endif; ?>
            <?php echo e($slot); ?>

        </button>
    </a>
    <?php else: ?>
    <button type="<?php echo e($type); ?>" <?php echo e($click !=null ? 'wire:click=' .$click.'':''); ?> <?php echo e($attributes->merge(['class' =>
        'text-base bg-'.$color.'-500 text-white font-bold px-3 py-1 rounded
        hover:bg-'.$color.'-600 focus:bg-'.$color.'-600 focus:outline-none focus:ring focus:ring-'.$color.'-600
        focus:ring-opacity-50 '.$class])); ?>>
        <?php if($icon != null): ?>
        <i class="<?php echo e($icon); ?> mr-2"></i>
        <?php endif; ?>
        <?php echo e($slot); ?>

    </button>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/button.blade.php ENDPATH**/ ?>