<div>
    <div class="grid grid-cols-12 grid-gap-5 mb-5">
        <div class="col-span-9"></div>
        <div class="col-span-3">
            <?php if (isset($component)) { $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Search::class, []); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65)): ?>
<?php $component = $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65; ?>
<?php unset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65); ?>
<?php endif; ?>
        </div>
    </div>
    <div wire:loading.remove wire:target="search">
        <?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, []); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('thead', null, []); ?> 
                <td class="w-16"></td>
                <th class="text-left px-3 py-2"><?php echo e(__('User')); ?></th>
                <th class="text-left px-3 py-2"><?php echo e(__('Name')); ?></th>
                <th class="text-left px-3 py-2"><?php echo e(__('Email')); ?></th>
                <th class="text-left px-3 py-2"><?php echo e(__('Permission')); ?></th>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('tbody', null, []); ?> 
                <?php if(count($users) == 0): ?>
                <tr>
                    <td colspan="4" class="text-center font-bold text-lg p-2 text-red-600">
                        <?php echo e(__('No record was found.')); ?>

                    </td>
                </tr>
                <?php else: ?>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($user->profile_photo_path): ?>
                        <a href="<?php echo e(route('users.edit',['id' => $user->id])); ?>"
                            class="text-red-600 font-bold hover:text-red-800">
                            <img src="<?php echo e(Storage::url($user->profile_photo_path)); ?>" class="rounded-full p-1 w-16 h-16">
                        </a>
                        <?php endif; ?>
                    </td>
                    <td class="text-left px-3 pr-2">
                        <a href="<?php echo e(route('users.edit',['id' => $user->id])); ?>"
                            class="text-red-600 font-bold hover:text-red-800"><?php echo e($user->username); ?></a>
                    </td>
                    <td class="text-left px-3 py-2"><?php echo e($user->name); ?></td>
                    <td class="text-left px-3 py-2"><?php echo e($user->email); ?></td>
                    <td class="text-left px-3 py-2">
                        <?php echo e($user->permission ? __($user->permission->name) : __('Without permits')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
             <?php $__env->endSlot(); ?>

             <?php $__env->slot('pagination', null, []); ?> 
                <?php echo e($users->links()); ?>

             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?>

    </div>
    <div wire:loading.delay wire:loading.inline wire:target="search">
        <?php if (isset($component)) { $__componentOriginald7e0e4ad27203c9b101a92eaeb2f1d5c375c9724 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\LoadingTable::class, ['rows' => '15','columns' => '4']); ?>
<?php $component->withName('loading-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7e0e4ad27203c9b101a92eaeb2f1d5c375c9724)): ?>
<?php $component = $__componentOriginald7e0e4ad27203c9b101a92eaeb2f1d5c375c9724; ?>
<?php unset($__componentOriginald7e0e4ad27203c9b101a92eaeb2f1d5c375c9724); ?>
<?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/user/table.blade.php ENDPATH**/ ?>