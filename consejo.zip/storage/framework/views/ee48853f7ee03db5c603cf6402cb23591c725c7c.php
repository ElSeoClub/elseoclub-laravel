<div>
    <div class="flex flex-col">
        <div class="bg-white shadow  rounded p-4">
            <div class="flex">
                <div class="h-48 w-48">
                    <img src="<?php echo e($image); ?>" class="w-48  object-scale-down object-cover h-48 rounded">
                </div>
                <div class="flex-auto ml-3 justify-evenly py-2">
                    <?php echo e($slot); ?>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/card-image.blade.php ENDPATH**/ ?>