<div>
    <div>
        <nav class="w-28 flex flex-col items-center bg-white dark:bg-gray-800 py-4">
            <div>
                <img src="<?php echo e(asset('svg/logo.svg')); ?>" width="50px" height="50px" />
            </div>
            <ul class="mt-2 text-gray-700 dark:text-gray-400 capitalize w-full p-1">
                <?php if (isset($component)) { $__componentOriginal830c22003853beb98d738587595aa16c97a5663d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\NavigationMenuOption::class, ['route' => route('legitimation.index'),'activeRoute' => 'legitimation.*','icon' => 'fas fa-gavel']); ?>
<?php $component->withName('layout.general.navigation-menu-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    Legitimaciones
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830c22003853beb98d738587595aa16c97a5663d)): ?>
<?php $component = $__componentOriginal830c22003853beb98d738587595aa16c97a5663d; ?>
<?php unset($__componentOriginal830c22003853beb98d738587595aa16c97a5663d); ?>
<?php endif; ?>

                
                <?php if(Auth::user()->hasPermission('Administrator')): ?>
                <li class="mt-2 pt-2 text-xs font-bold text-center text-red-700 uppercase border-t border-gray-200">
                    Admin
                </li>
                <?php if (isset($component)) { $__componentOriginal830c22003853beb98d738587595aa16c97a5663d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\NavigationMenuOption::class, ['route' => route('users.index'),'activeRoute' => 'users.*','icon' => 'fas fa-users']); ?>
<?php $component->withName('layout.general.navigation-menu-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <?php echo e(__("Users")); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830c22003853beb98d738587595aa16c97a5663d)): ?>
<?php $component = $__componentOriginal830c22003853beb98d738587595aa16c97a5663d; ?>
<?php unset($__componentOriginal830c22003853beb98d738587595aa16c97a5663d); ?>
<?php endif; ?>

                <li class="mt-2 pt-2 text-xs font-bold text-center text-red-700 uppercase border-t border-gray-200">
                    Catálogos
                </li>
                <?php if (isset($component)) { $__componentOriginal830c22003853beb98d738587595aa16c97a5663d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\NavigationMenuOption::class, ['route' => route('legitimation.evidence.types'),'activeRoute' => 'users.*','icon' => 'fas fa-gavel']); ?>
<?php $component->withName('layout.general.navigation-menu-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <?php echo e(__("Evidencias")); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830c22003853beb98d738587595aa16c97a5663d)): ?>
<?php $component = $__componentOriginal830c22003853beb98d738587595aa16c97a5663d; ?>
<?php unset($__componentOriginal830c22003853beb98d738587595aa16c97a5663d); ?>
<?php endif; ?>
                <?php endif; ?>

                <li class="mt-2 pt-2 text-xs font-bold text-center text-red-700 uppercase border-t border-gray-200">
                </li>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if (isset($component)) { $__componentOriginal830c22003853beb98d738587595aa16c97a5663d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\NavigationMenuOption::class, ['onclick' => 'event.preventDefault();this.closest(\'form\').submit();','route' => route('logout'),'icon' => 'fas fa-door-open']); ?>
<?php $component->withName('layout.general.navigation-menu-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        <?php echo e(__("Exit")); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal830c22003853beb98d738587595aa16c97a5663d)): ?>
<?php $component = $__componentOriginal830c22003853beb98d738587595aa16c97a5663d; ?>
<?php unset($__componentOriginal830c22003853beb98d738587595aa16c97a5663d); ?>
<?php endif; ?>
                </form>
            </ul>
        </nav>
    </div>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/layout/general/navigation-menu.blade.php ENDPATH**/ ?>