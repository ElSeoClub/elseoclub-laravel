<div>
    <?php if (isset($component)) { $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Search::class, []); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65)): ?>
<?php $component = $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65; ?>
<?php unset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['title' => 'Tipos de evidencia','px' => '0','py' => '0']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, []); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('thead', null, []); ?> 
                <th class="px-5 py-3 text-left">Nombre</th>
                <th class="px-5 py-3 text-left">Descripción</th>
                <th class="w-12 px-5 py-3">Ejemplo</th>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('tbody', null, []); ?> 
                <?php if(count($evidences) == 0): ?>
                <tr>
                    <td colspan="3" class="text-center font-bold text-red-500 py-3">
                        No hay ningún tipo de evidencia aún.
                    </td>
                </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $evidences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-100">
                    <td class="px-5 py-3">
                        <?php if (isset($component)) { $__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\A::class, ['href' => route('legitimation.evidence.types.edit',['evidence' => $evidence->id])]); ?>
<?php $component->withName('a'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <?php echo e($evidence->name); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3)): ?>
<?php $component = $__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3; ?>
<?php unset($__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3); ?>
<?php endif; ?>
                    </td>
                    <td class="px-5 py-3"><?php echo e($evidence->description); ?></td>
                    <td class="px-5 py-3 text-center">
                        <?php if (isset($component)) { $__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\A::class, ['href' => ''.e(Storage::url($evidence->path)).'','download' => 'true']); ?>
<?php $component->withName('a'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><i class="fas fa-download"></i>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3)): ?>
<?php $component = $__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3; ?>
<?php unset($__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3); ?>
<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('paginate', null, []); ?> 
                <?php echo e($evidences->links()); ?>

             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?>
         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['color' => 'blue','icon' => 'fas fa-plus','href' => route('legitimation.evidence.types.create')]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Agregar tipo
                de evidencia <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/event/legitimation/evidence/types.blade.php ENDPATH**/ ?>