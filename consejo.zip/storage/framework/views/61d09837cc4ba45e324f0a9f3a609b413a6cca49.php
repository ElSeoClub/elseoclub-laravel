<?php if (isset($component)) { $__componentOriginal2a0a7172c3fd1f00d2835d9a2f0ace8b2c503d8d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GeneralLayout::class, []); ?>
<?php $component->withName('general-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Legitimaciones <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal01f05b556a84c538e676f97d34588c425ae2defc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\Breadcrumbs::class, []); ?>
<?php $component->withName('layout.general.breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\BreadcrumbOption::class, ['name' => 'Legitimaciones','arrow' => 'true','route' => route('legitimation.index')]); ?>
<?php $component->withName('layout.general.breadcrumb-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d)): ?>
<?php $component = $__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d; ?>
<?php unset($__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\BreadcrumbOption::class, ['name' => 'Crear','arrow' => 'false']); ?>
<?php $component->withName('layout.general.breadcrumb-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d)): ?>
<?php $component = $__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d; ?>
<?php unset($__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01f05b556a84c538e676f97d34588c425ae2defc)): ?>
<?php $component = $__componentOriginal01f05b556a84c538e676f97d34588c425ae2defc; ?>
<?php unset($__componentOriginal01f05b556a84c538e676f97d34588c425ae2defc); ?>
<?php endif; ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('event.legitimation.create')->html();
} elseif ($_instance->childHasBeenRendered('qOHdbTF')) {
    $componentId = $_instance->getRenderedChildComponentId('qOHdbTF');
    $componentTag = $_instance->getRenderedChildComponentTagName('qOHdbTF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qOHdbTF');
} else {
    $response = \Livewire\Livewire::mount('event.legitimation.create');
    $html = $response->html();
    $_instance->logRenderedChild('qOHdbTF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a0a7172c3fd1f00d2835d9a2f0ace8b2c503d8d)): ?>
<?php $component = $__componentOriginal2a0a7172c3fd1f00d2835d9a2f0ace8b2c503d8d; ?>
<?php unset($__componentOriginal2a0a7172c3fd1f00d2835d9a2f0ace8b2c503d8d); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\consejo\resources\views/event/legitimation/create.blade.php ENDPATH**/ ?>