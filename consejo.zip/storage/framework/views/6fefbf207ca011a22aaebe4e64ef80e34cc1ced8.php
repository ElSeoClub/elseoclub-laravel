<?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, []); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('thead', null, []); ?> 
        <th class="text-left p-3">Sede</th>
        <th class="text-center p-3">Votos si</th>
        <th class="text-center p-3">Votos no</th>
        <th class="text-center p-3">Voto nulo</th>
        <th></th>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('tbody', null, []); ?> 
        <?php $__currentLoopData = $user_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $location->doors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $door): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="p-3">
                <?php if (isset($component)) { $__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\A::class, ['href' => route('legitimation.votting.locationseccion',['event' => $event->id, 'location' => $location->id, 'door' => $door->id])]); ?>
<?php $component->withName('a'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <?php echo e($location->name); ?> Sección <?php echo e($door->name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3)): ?>
<?php $component = $__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3; ?>
<?php unset($__componentOriginal9e31a2e6fccdde27fc35f49f74d2bf272dc17ea3); ?>
<?php endif; ?>
            </td>
            <td class="text-center p-3"><?php echo e(($door->si ?? 0)); ?></td>
            <td class="text-center p-3"><?php echo e(($door->no ?? 0)); ?></td>
            <td class="text-center p-3"><?php echo e(($door->nulos ?? 0)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/event/legitimation/votting/seccion.blade.php ENDPATH**/ ?>