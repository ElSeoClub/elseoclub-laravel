<div>
    <li class="flex items-center text-red-700 hover:text-red-500">
        <?php if($route): ?>
        <a href="<?php echo e($route); ?>"><?php echo e($name); ?></a>
        <?php else: ?>
        <span class="text-gray-600 hover:text-gray-600"><?php echo e($name); ?></span>
        <?php endif; ?>
        <?php if($arrow == 'true'): ?>
        <i class="text-sm fas fa-chevron-right mx-3 text-black hover:text-black"></i>
        <?php endif; ?>
    </li>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/layout/general/breadcrumb-option.blade.php ENDPATH**/ ?>