<div>
    <?php if($view == 'show'): ?>
    <div class="grid grid-cols-4 gap-5">
        <div class="col-span-3">
            <div class="grid grid-cols-4 gap-5">
                <div class="col-span-3"></div>
                <div>
                    <?php if (isset($component)) { $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Search::class, []); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65)): ?>
<?php $component = $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65; ?>
<?php unset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65); ?>
<?php endif; ?>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, []); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('thead', null, []); ?> 
                    <th class="py-3 px-6 text-left">Clave de empleado</th>
                    <th class="py-3 px-6 text-left">Nombre</th>
                    <th class="py-3 px-6 text-left">Sede</th>
                    <th class="py-3 px-6 text-left">Puerta</th>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('tbody', null, []); ?> 
                    <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="py-3 px-6 text-left whitespace-nowrap flex">
                            <img src="<?php echo e(Storage::url($user->profile_photo_path)); ?>"
                                class="rounded-full h-12 w-12 object-cover">
                            <span class="ml-2 pt-3"><?php echo e($user->username); ?></span>
                        </td>
                        <td class="py-3 px-6 text-left whitespace-nowrap"><?php echo e($user->name); ?></td>
                        <td class="py-3 px-6 text-left whitespace-nowrap">
                            <?php echo e($user->location()->name); ?></td>
                        <td class="py-3 px-6 text-left whitespace-nowrap">
                            <?php echo e($user->door()->name); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('pagination', null, []); ?> 
                    <?php echo e($user_list->links()); ?>

                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?>
        </div>
        <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['title' => 'Actualizar padrón','icon' => 'fas fa-user-edit']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <input id="csv_file" type="file" accept=".csv" class="form-control" name="csv_file" wire:model="users"
                required>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'users']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'users']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
             <?php $__env->slot('footer', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['class' => 'w-full','color' => 'blue','icon' => 'fas fa-user-edit','click' => 'update']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:target' => 'users']); ?>Actualizar padrón
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
    </div>
    <?php else: ?>
    <?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, []); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('thead', null, []); ?> 
            <th class="py-3 px-6 text-left">Clave de empleado</th>
            <th class="py-3 px-6 text-left">Nombre</th>
            <th class="py-3 px-6 text-left">Sede</th>
            <th class="py-3 px-6 text-left">Puerta</th>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('tbody', null, []); ?> 
            <?php $__currentLoopData = $users_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user['new'] === true): ?>
            <tr class="border-b border-gray-200 hover:bg-gray-100">
                <td class="text-green-600 py-3 px-6 text-left whitespace-nowrap"><?php echo e($user['username']); ?></td>
                <td class="text-green-600 py-3 px-6 text-left whitespace-nowrap"><?php echo e($user['name']); ?></td>
                <td class="py-3 px-6 text-left <?php echo e($user['new_sede'] == true ? '': 'text-green-600'); ?>">
                    <?php echo e($user['sede']); ?>

                </td>
                <td class="py-3 px-6 text-left <?php echo e($user['new_door'] == true ? '': 'text-green-600'); ?>">
                    <?php echo e($user['door']); ?>

                </td>
            </tr>
            <?php else: ?>
            <tr class="border-b border-gray-200 hover:bg-gray-100">
                <td class="py-3 px-6 text-left whitespace-nowrap"><?php echo e($user['username']); ?></td>
                <td class="py-3 px-6 text-left <?php echo e($user['name'] == $user['db']['name'] ? '': 'text-green-600'); ?>">
                    <?php echo $user['name'] == $user['db']['name'] ? '': '<span class="text-gray-500
                        line-through">'.$user['db']['name'].'</span><br />'; ?>

                    <?php echo e($user['name'] == $user['db']['name'] ? $user['db']['name']: $user['name']); ?></td>
                <td class="py-3 px-6 text-left <?php echo e($user['new_sede'] == true ? '': 'text-green-600'); ?>">
                    <?php echo e($user['sede']); ?>

                </td>
                <td class="py-3 px-6 text-left <?php echo e($user['new_door'] == true ? '': 'text-green-600'); ?>">
                    <?php echo e($user['door']); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['color' => 'blue','icon' => 'fas fa-user-edit','click' => 'save']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        Actualizar padrón
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
    <?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/event/legitimation/guests.blade.php ENDPATH**/ ?>