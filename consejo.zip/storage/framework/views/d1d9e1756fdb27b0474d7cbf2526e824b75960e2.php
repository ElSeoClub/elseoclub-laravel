<?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, []); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('thead', null, []); ?> 
        <th class="text-left p-3">Sede</th>
        <th class="text-left p-3">Puerta</th>
        <th class="text-left p-3">Avance</th>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('tbody', null, []); ?> 
        <?php $__currentLoopData = $user_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $location->doors()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $door): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="p-3"><a href="<?php echo e(route('legitimation.attendance.screen',['door' => $door->id])); ?>"
                    class="text-red-600 font-bold hover:text-red-800"><?php echo e($location->name); ?></a></td>
            <td class="p-3"><?php echo e($door->name); ?></td>
            <td class="text-left whitespace-nowrap pt-3 px-6">
                <div class="shadow-md w-full bg-gray-200 h-6 mb-3 flex">
                    <div class="bg-green-500 text-xs leading-none text-center text-white h-full py-1 font-bold text-base z-10"
                        style="width: <?php echo e($door->guests()->count() > 0 ? round(($door->guests()->where('attendance_door_id',$door->id)->count()/$door->guests()->count())*100,0):'0'); ?>%">
                        <?php echo e($door->guests()->count() > 0 ?
                        (round(($door->guests()->where('attendance_door_id',$door->id)->count()/$door->guests()->count())*100,0)+round(($door->guests()->whereNotNull('attendance_door_id')->where('attendance_door_id','!=',$door->id)->count()/$door->guests()->count())*100,0))
                        :'0'); ?>%

                    </div>
                    <div class="bg-green-700 text-xs leading-none text-center text-white h-full py-1 font-bold text-base"
                        style="width: <?php echo e($door->guests()->count() > 0 ? (round(($door->guests()->whereNotNull('attendance_door_id')->where('attendance_door_id','!=',$door->id)->count()/$door->guests()->count())*100,0)):'0'); ?>%">
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/event/legitimation/attendance/index.blade.php ENDPATH**/ ?>