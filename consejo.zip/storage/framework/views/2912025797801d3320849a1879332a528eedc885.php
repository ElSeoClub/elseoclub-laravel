<div>
    <div class="rounded shadow bg-white mb-5">
        <?php if($title): ?>
        <div class="flex justify-between border-b border-gray-200 px-6 py-3">
            <div>
                <i class="<?php echo e($icon); ?> text-<?php echo e($color); ?>-500 mr-2"></i>
                <span class="font-bold text-gray-700 text-lg"><?php echo e($title); ?></span>
            </div>
        </div>
        <?php endif; ?>
        <div class="px-<?php echo e($px); ?> py-<?php echo e($py); ?> text-gray-600">
            <?php echo e($slot); ?>

        </div>

        <?php if($footer): ?>
        <div class="border-t border-gray-200 px-5 py-3">
            <?php echo e($footer); ?>

        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/card.blade.php ENDPATH**/ ?>