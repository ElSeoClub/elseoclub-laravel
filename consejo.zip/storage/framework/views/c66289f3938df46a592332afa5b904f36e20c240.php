<div>
    <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, []); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <div class="grid grid-cols-12">
            <div class="col-span-4 text-right pt-3 border-r pr-4 mb-3">
                <p class="font-bold"><?php echo e(__('Convocatoria')); ?></p>
                <p class="text-sm">
                    <?php echo e(__("Elige el archivo de la convocatoria de la sede.")); ?>

                </p>
            </div>
            <div class="col-span-8 pl-4 mb-3">
                <div class="py-3 center mx-auto">
                    <div class="bg-white px-4 py-5 rounded-lg text-center w-72">
                        <label class="cursor-pointer mt-6 mb-5">
                            <span
                                class="mt-2 text-base leading-normal px-4 py-2 bg-blue-500 text-white text-sm rounded-full">
                                <?php echo e(__('Elegir convocatoria')); ?>

                            </span>
                            <input type='file' class="hidden" wire:model="convocatoria" />
                        </label>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'convocatoria','class' => 'mt-5']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'convocatoria','class' => 'mt-5']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                    <?php if($convocatoria): ?>
                    <div class="text-left w-full mt-5">
                        <?php echo e($convocatoria->getClientOriginalName()); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-span-4 text-right pt-3 border-r pr-4 mb-3">
                <p class="font-bold"><?php echo e(__('# Boletas')); ?></p>
                <p class="text-sm">
                    <?php echo e(__("Elige la cantidad de boletas entregadas en la sede.")); ?>

                </p>
            </div>
            <div class="col-span-8 pl-4 mb-3">
                <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'numeric','model' => 'location.boletas']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
            </div>
            <div class="col-span-4 text-right pt-3 border-r pr-4 mb-3">
                <p class="font-bold"><?php echo e(__('Dirección')); ?></p>
                <p class="text-sm">
                    <?php echo e(__("Es la dirección donde se realizara la la votación.")); ?>

                </p>
            </div>
            <div class="col-span-8 pl-4 mb-3">
                <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'numeric','model' => 'location.description']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
            </div>
            <div class="col-span-4 text-right pt-3 border-r pr-4 mb-3">
                <p class="font-bold"><?php echo e(__('Ubicación GPS')); ?></p>
                <p class="text-sm">
                    <?php echo e(__("Es la liga de la ubicación GPS.")); ?>

                </p>
            </div>
            <div class="col-span-8 pl-4 mb-3">
                <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'numeric','model' => 'location.georeferences']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
            </div>
            <div class="col-span-4 text-right pt-3 border-r pr-4 mb-3">
                <p class="font-bold"><?php echo e(__('Horario')); ?></p>
                <p class="text-sm">
                    <?php echo e(__("Es el horario en el que se realizará la votación (8:00 a 18:00 hrs).")); ?>

                </p>
            </div>
            <div class="col-span-8 pl-4 mb-3">
                <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'numeric','model' => 'location.schedule']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
            </div>

            <div class="col-span-4 text-right pt-3 border-r pr-4 mb-3">
                <p class="font-bold"><?php echo e(__('Gestores de la sede')); ?></p>
                <p class="text-sm">
                    <?php echo e(__("Es la lista de personas que pueden interactuar con la sede")); ?>

                </p>
            </div>
            <div class="col-span-8 pl-4 mb-3">
                <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'numeric','model' => 'user','label' => 'Usuario']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
                <div class="grid grid-cols-2 gap-5">
                    <div>
                        <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex justify-between py-3 px-3 hover:bg-gray-100">

                            <div class="flex">
                                <img src="<?php echo e(Storage::url($user->profile_photo_path)); ?>" class="w-12 h-12">
                                <div class="grid grid-cols-1 px-3">
                                    <span><?php echo e(strtoupper($user->name)); ?></span>
                                    <div>
                                        <span
                                            class="bg-blue-600 font-bold text-white px-1 rounded text-sm"><?php echo e($user->permission->name
                                            ??
                                            'Sin
                                            permisos'); ?></span>
                                    </div>
                                </div>
                            </div>
                            <span class="pt-3"><i
                                    class="fa fa-arrow-right text-gray-600 hover:text-gray-900 cursor-pointer"
                                    wire:click="add_user(<?php echo e($user->id); ?>)"></i></span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex justify-between py-3 px-3 hover:bg-gray-100">

                            <div class="flex">
                                <img src="<?php echo e(Storage::url($user->profile_photo_path)); ?>" class="w-12 h-12">
                                <div class="grid grid-cols-1 px-3">
                                    <span><?php echo e(strtoupper($user->name)); ?></span>
                                    <div>
                                        <span
                                            class="bg-blue-600 font-bold text-white px-1 rounded text-sm"><?php echo e($user->permission->name
                                            ??
                                            'Sin
                                            permisos'); ?></span>
                                    </div>
                                </div>
                            </div>
                            <span class="pt-3"><i class="fa fa-times text-gray-600 hover:text-red-600 cursor-pointer"
                                    wire:click="remove_user(<?php echo e($user->id); ?>)"></i></span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
         <?php $__env->slot('footer', null, []); ?> 
            <div wire:loading wire:target="convocatoria">
                Espera un momento, estamos subiendo el documento.
            </div>
            <?php if($convocatoria): ?>
            <div wire:loading.remove wire:target="convocatoria">
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['icon' => 'fas fa-save','color' => 'blue','click' => 'save']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Guardar cambios <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
            </div>
            <?php else: ?>
            <div wire:loading.remove wire:target="convocatoria">
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['icon' => 'fas fa-save','color' => 'blue','click' => 'save']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Guardar cambios <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
            </div>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/event/legitimation/location/location.blade.php ENDPATH**/ ?>