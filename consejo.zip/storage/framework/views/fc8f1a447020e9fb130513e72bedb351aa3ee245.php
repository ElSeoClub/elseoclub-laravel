<div>
    <nav class="text-black font-bold mb-5" aria-label="Breadcrumb">
        <ol class="list-none p-0 inline-flex">
            <?php echo e($slot); ?>

        </ol>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/layout/general/breadcrumbs.blade.php ENDPATH**/ ?>