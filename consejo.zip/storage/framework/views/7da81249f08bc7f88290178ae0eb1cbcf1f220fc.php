<?php if (isset($component)) { $__componentOriginal2a0a7172c3fd1f00d2835d9a2f0ace8b2c503d8d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GeneralLayout::class, []); ?>
<?php $component->withName('general-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Legitimaciones <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal01f05b556a84c538e676f97d34588c425ae2defc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\Breadcrumbs::class, []); ?>
<?php $component->withName('layout.general.breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\BreadcrumbOption::class, ['name' => 'Legitimaciones','arrow' => 'true','route' => route('legitimation.index')]); ?>
<?php $component->withName('layout.general.breadcrumb-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d)): ?>
<?php $component = $__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d; ?>
<?php unset($__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\General\BreadcrumbOption::class, ['name' => $event->name,'arrow' => 'false']); ?>
<?php $component->withName('layout.general.breadcrumb-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d)): ?>
<?php $component = $__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d; ?>
<?php unset($__componentOriginal3c546dd09b23b02971df5c788e11da85822ee24d); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01f05b556a84c538e676f97d34588c425ae2defc)): ?>
<?php $component = $__componentOriginal01f05b556a84c538e676f97d34588c425ae2defc; ?>
<?php unset($__componentOriginal01f05b556a84c538e676f97d34588c425ae2defc); ?>
<?php endif; ?>
    <div class="grid grid-cols-2 gap-5 mb-5">
        <?php if(Auth::user()->hasPermission('Administrator')): ?>
        <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/note.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="font-bold text-2xl">Padrón del evento</div>
            <div><?php echo e($event->guests()->count()); ?> Invitados en <?php echo e($event->locations()->count()); ?> sedes</div>
            <div class="mt-20 w-full">
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => ''.e(route('legitimation.guests', ['event' => $event])).'','color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    Gestionar padrón <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/map.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="font-bold text-2xl">Sedes del evento</div>
            <div>&nbsp;</div>
            <div class="mt-20 w-full">
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => ''.e(route('legitimation.locations', ['event' => $event])).'','color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    Gestionar sedes <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/open-door.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="font-bold text-2xl">Puertas del evento</div>
            <div>&nbsp;</div>
            <div class="mt-20 w-full">
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => ''.e(route('legitimation.doors.index', ['event' => $event])).'','color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    Gestionar puertas <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/steps.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="font-bold text-2xl">Seguimiento de las sedes</div>
                <div>&nbsp;</div>
                <div class="mt-20 w-full">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => ''.e(route('legitimation.statistics', ['event' => $event])).'','color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        Ver seguimiento <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/statistics.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="font-bold text-2xl">Estadísticas y reportes</div>
                <div>&nbsp;</div>
                <div class="mt-20 w-full">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => ''.e(route('legitimation.reports.index', ['event' => $event])).'','color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        Ver estadísticas <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/vote1.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="font-bold text-2xl">Computo de resultados por sección</div>
                <div>&nbsp;</div>
                <div class="mt-20 w-full">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => ''.e(route('legitimation.vottingseccion',['event' => $event])).'','color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        Gestionar
                        votaciones <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/voting.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="font-bold text-2xl">Computo de resultados por sede</div>
                <div>&nbsp;</div>
                <div class="mt-20 w-full">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => ''.e(route('legitimation.votting',['event' => $event])).'','color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        Gestionar
                        votaciones <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/printer.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="font-bold text-2xl">Expediente para el día del evento</div>
                <div>&nbsp;</div>
                <div class="mt-20 w-full">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => route('legitimation.archive.index',compact('event')),'color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Ver
                        expediente <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/qr.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="font-bold text-2xl">Cédula de identificación de temporales</div>
                <div>&nbsp;</div>
                <div class="mt-20 w-full">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => route('legitimation.credentials.index',compact('event')),'color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        Ver
                        cédulas <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if(Auth::user()->hasPermission('Enlace Siconecta') || Auth::user()->hasPermission('Administrator')): ?>

        <?php endif; ?>

        <?php if(Auth::user()->hasPermission('Enlace Siconecta') || Auth::user()->hasPermission('Administrator') ||
        Auth::user()->hasPermission('Jurídico') || Auth::user()->hasPermission('Jurídico Global')): ?>

        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/immigration.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="font-bold text-2xl">Pase de asistencia</div>
            <div>&nbsp;</div>
            <div class="mt-20 w-full">
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => ''.e(route('legitimation.attendance',['event' => $event])).'','color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    Gestionar asistencia <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>


        <?php if(Auth::user()->hasPermission('Administrator') || Auth::user()->hasPermission('Jurídico')): ?>
        <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/vote.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="font-bold text-2xl">Computo de resultado final</div>
            <div>&nbsp;</div>
            <div class="mt-20 w-full">
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => ''.e(route('legitimation.votting.juridico',['event' => $event])).'','color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    Gestionar
                    votaciones <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardImage::class, ['image' => ''.e(asset('svg/folder.svg')).'']); ?>
<?php $component->withName('card-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="font-bold text-2xl">Evidencia del proceso de legitimación</div>
            <div>&nbsp;</div>
            <div class="mt-20 w-full">
                <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['href' => route('legitimation.evidence.index',compact('event')),'color' => 'blue','class' => 'w-full']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    Gestionar evidencia <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9)): ?>
<?php $component = $__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9; ?>
<?php unset($__componentOriginal538202d8ad33ff85f235c5566bb06604192c5df9); ?>
<?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a0a7172c3fd1f00d2835d9a2f0ace8b2c503d8d)): ?>
<?php $component = $__componentOriginal2a0a7172c3fd1f00d2835d9a2f0ace8b2c503d8d; ?>
<?php unset($__componentOriginal2a0a7172c3fd1f00d2835d9a2f0ace8b2c503d8d); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\consejo\resources\views/event/legitimation/show.blade.php ENDPATH**/ ?>