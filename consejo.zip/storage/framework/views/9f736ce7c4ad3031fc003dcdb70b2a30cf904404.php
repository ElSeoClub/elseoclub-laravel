<?php $attributes = $attributes->exceptProps([
'pagination' => null
]); ?>
<?php foreach (array_filter(([
'pagination' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <div class="bg-white shadow-md rounded ">
        <table class="min-w-max w-full table-auto">
            <thead>
                <tr class="bg-gray-100 text-gray-600 uppercase text-sm">
                    <?php echo e($thead); ?>

                </tr>
            </thead>
            <tbody class="text-gray-600 text-sm font-light">
                <?php echo e($tbody); ?>

            </tbody>
        </table>
        <?php if($pagination != null && strpos($pagination,'navigation') !== false): ?>
        <div class="py-3 px-6 bg-gray-100">
            <?php echo e($pagination); ?>

        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/components/table.blade.php ENDPATH**/ ?>