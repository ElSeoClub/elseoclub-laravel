<div>

    <?php if (isset($component)) { $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Search::class, []); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65)): ?>
<?php $component = $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65; ?>
<?php unset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65); ?>
<?php endif; ?>
    <div class="grid grid-cols-3 gap-3" wire:poll.30000ms>
        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['title' => ''.e($location->name).'']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="flex justify-between">
                <div class="py-2"><i
                        class="fas fa-<?php echo e($location->llegada_verificador != null ? 'check':'times'); ?> text-<?php echo e($location->llegada_verificador != null ? 'green':'gray'); ?>-600">
                    </i> Llegada del verificador</div>
                <?php if($location->llegada_verificador == null): ?>
                <div style="width:153px">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['class' => 'w-full','click' => 'llegada('.e($location->id).')']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Registrar llegada <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="flex justify-between">
                <div class="py-2">
                    <i
                        class="fas fa-<?php echo e($location->apertura != null ? 'check':'times'); ?> text-<?php echo e($location->apertura != null ? 'green':'gray'); ?>-600">
                    </i>
                    Inicio de votaciones
                </div>

                <?php if($location->apertura == null): ?>
                <div style="width:153px">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['class' => 'w-full','click' => 'apertura('.e($location->id).')']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Registrar Inicio <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="flex justify-between">
                <div class="py-2">
                    <i
                        class="fas fa-<?php echo e($location->cierre != null  ? 'check':'times'); ?> text-<?php echo e($location->cierre != null ? 'green':'gray'); ?>-600">
                    </i> Cierre de votaciones
                </div>
                <?php if($location->cierre == null && $location->apertura != null): ?>
                <div style="width:153px">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['class' => 'w-full','click' => 'cierre('.e($location->id).')']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Registrar cierre <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="flex justify-between">
                <div class="py-2">
                    <i
                        class="fas fa-<?php echo e($location->conteo != null  ? 'check':'times'); ?> text-<?php echo e($location->conteo != null  ? 'green':'gray'); ?>-600">
                    </i> Inició conteo de votos
                </div>
                <?php if($location->conteo == null && $location->apertura != null && $location->cierre != null): ?>
                <div style="width:153px">
                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['class' => 'w-full','click' => 'conteo('.e($location->id).')']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Iniciar conteo <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="relative pt-1">
                <div class="flex mb-2 items-center justify-between">
                    <div>
                        <span class="
                    text-xs
                    font-semibold
                    inline-block
                    py-1
                    px-2
                    uppercase
                    rounded-full
                    text-gray-600
                    bg-gray-200
                  ">
                            Asistencia
                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xs font-semibold inline-block text-gray-600">
                            <?php echo e($location->guests()->whereNotNull('attendance_door_id')->count()); ?> de
                            <?php echo e($location->guests()->count()); ?>

                        </span>
                    </div>
                    <div class="text-right">
                        <span class="text-xs font-semibold inline-block text-gray-600">
                            <?php echo e($location->guests()->count() > 0
                            ?round(($location->guests()->whereNotNull('attendance_door_id')->count()/$location->guests()->count())*100,0)
                            : '0'); ?>%


                        </span>
                    </div>
                </div>
                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                    <div style="width: <?php echo e($location->guests()->count() > 0 ?round(($location->guests()->whereNotNull('attendance_door_id')->count()/$location->guests()->count())*100,0) : '0'); ?>%"
                        class="
                  shadow-none
                  flex flex-col
                  text-center
                  whitespace-nowrap
                  text-white
                  justify-center
                  bg-green-500
                "></div>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/event/legitimation/statistics/index.blade.php ENDPATH**/ ?>