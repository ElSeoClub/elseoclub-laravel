<div wire:poll.120000ms>
    <div class="grid lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-4 px-4 mb-5">
        <!-- SMALL CARD ROUNDED -->
        <div wire:click="display('status')"
            class="bg-<?php echo e($view == 'status' ? 'red-50':'gray-100'); ?> border-<?php echo e($view == 'status' ? 'red-900':'gray-600'); ?> bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | flex justify-between cursor-pointer | hover:bg-gray-200  hover:border-gray-700 | transition-colors duration-500">
            <img class="w-16 h-16 object-cover" src="<?php echo e(asset('svg/status.svg')); ?>" alt="" />
            <div class="flex flex-col justify-center">
                <p class="text-gray-900 dark:text-gray-300 font-semibold text-xl">Estado de las sedes</p>
            </div>
        </div>
        <div wire:click="display('attendance')"
            class="bg-<?php echo e($view == 'attendance' ? 'red-50':'gray-100'); ?> border-<?php echo e($view == 'attendance' ? 'red-900':'gray-600'); ?> bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | flex justify-between cursor-pointer | hover:bg-gray-200  hover:border-gray-700 | transition-colors duration-500">
            <img class="w-16 h-16 object-cover" src="<?php echo e(asset('svg/attendant-list.svg')); ?>" alt="" />
            <div class="flex flex-col justify-center">
                <p class="text-gray-900 dark:text-gray-300 font-semibold text-xl">Asistencia de las sedes</p>
            </div>
        </div>
        <div wire:click="display('attendance2')"
            class="bg-<?php echo e($view == 'attendance2' ? 'red-50':'gray-100'); ?> border-<?php echo e($view == 'attendance2' ? 'red-900':'gray-600'); ?> bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | flex justify-between cursor-pointer | hover:bg-gray-200  hover:border-gray-700 | transition-colors duration-500">
            <img class="w-16 h-16 object-cover" src="<?php echo e(asset('svg/organization.svg')); ?>" alt="" />
            <div class="flex flex-col justify-center">
                <p class="text-gray-900 dark:text-gray-300 font-semibold text-xl">Asistencia por coordinación</p>
            </div>
        </div>
        <div wire:click="display('count')"
            class="bg-<?php echo e($view == 'count' ? 'red-50':'gray-100'); ?> border-<?php echo e($view == 'count' ? 'red-900':'gray-600'); ?> bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | flex justify-between cursor-pointer | hover:bg-gray-200  hover:border-gray-700 | transition-colors duration-500">
            <img class="w-16 h-16 object-cover" src="<?php echo e(asset('svg/results.svg')); ?>" alt="" />
            <div class="flex flex-col justify-center">
                <p class="text-gray-900 dark:text-gray-300 font-semibold text-xl">Preliminar de votaciones por sede</p>
            </div>
        </div>
        <div wire:click="display('count2')"
            class="bg-<?php echo e($view == 'count2' ? 'red-50':'gray-100'); ?> border-<?php echo e($view == 'count2' ? 'red-900':'gray-600'); ?> bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | flex justify-between cursor-pointer | hover:bg-gray-200  hover:border-gray-700 | transition-colors duration-500">
            <img class="w-16 h-16 object-cover" src="<?php echo e(asset('svg/results.svg')); ?>" alt="" />
            <div class="flex flex-col justify-center">
                <p class="text-gray-900 dark:text-gray-300 font-semibold text-xl">Preliminar de votaciones por
                    coordinación
                </p>
            </div>
        </div>
    </div>

    <?php if($view == 'status'): ?>
    <div>
        <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['icon' => 'fab fa-searchengin','title' => 'Llegada del verificador por sede']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="flex gap-5 flex-wrap">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="w-12 h-12 text-center bg-<?php echo e($location->llegada_verificador != null ? 'green':'gray'); ?>-600 text-white rounded-full flex content-center flex-wrap justify-center font-bold text-xl">
                    <div><?php echo e($location->name); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['icon' => 'fas fa-play','title' => 'Inicio del proceso de votación']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="flex gap-5 flex-wrap">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="w-12 h-12 text-center bg-<?php echo e($location->apertura != null ? 'green':'gray'); ?>-600 text-white rounded-full flex content-center flex-wrap justify-center font-bold text-xl">
                    <div><?php echo e($location->name); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['icon' => 'fas fa-stop','title' => 'Cierre del centro de votación']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="flex gap-5 flex-wrap">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="w-12 h-12 text-center bg-<?php echo e($location->cierre != null ? 'green':'gray'); ?>-600 text-white rounded-full flex content-center flex-wrap justify-center font-bold text-xl">
                    <div><?php echo e($location->name); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['icon' => 'fas fa-stopwatch-20','title' => 'Inicio de conteo de votos']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="flex gap-5 flex-wrap">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="w-12 h-12 text-center bg-<?php echo e($location->conteo != null ? 'green':'gray'); ?>-600 text-white rounded-full flex content-center flex-wrap justify-center font-bold text-xl">
                    <div><?php echo e($location->name); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
    </div>
    <?php elseif($view == 'attendance'): ?>
    <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['icon' => 'fab fa-searchengin','title' => 'Asistencia por sede']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <div class="relative pt-1 hover:border-gray-400 border-white border border-solid p-1 rounded">
            <div class="flex mb-2 items-center justify-between">
                <div>
                    <span class="
                text-xs
                font-semibold
                inline-block
                py-1
                px-2
                uppercase
                rounded-full
                text-gray-600
                bg-gray-200
              ">
                        GLOBAL
                    </span>
                </div>
                <div class="text-left">
                    <span class="text-xs font-semibold inline-block text-gray-600">
                        <?php echo e($event->guests()->whereNotNull('attendance_door_id')->count()); ?> de
                        72220
                    </span>
                </div>
                <div class="text-right">
                    <span class="text-xs font-semibold inline-block text-gray-600">
                        <?php echo e($event->guests()->count() > 0
                        ?round(($event->guests()->whereNotNull('attendance_door_id')->count()/$event->guests()->count())*100,0)
                        : '0'); ?>%


                    </span>
                </div>
            </div>
            <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                <div style="width: <?php echo e($event->guests()->count() > 0 ?round(($event->guests()->whereNotNull('attendance_door_id')->count()/$event->guests()->count())*100,0) : '0'); ?>%"
                    class="
              shadow-none
              flex flex-col
              text-center
              whitespace-nowrap
              text-white
              justify-center
              bg-green-500
            "></div>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-5">
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative pt-1 hover:border-gray-400 border-white border border-solid p-1 rounded">
                <div class="flex mb-2 items-center justify-between">
                    <div>
                        <span class="
                    text-xs
                    font-semibold
                    inline-block
                    py-1
                    px-2
                    uppercase
                    rounded-full
                    text-gray-600
                    bg-gray-200
                  ">
                            Sede <?php echo e($location->name); ?>

                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xs font-semibold inline-block text-gray-600">
                            <?php echo e($location->guests()->whereNotNull('attendance_door_id')->count()); ?> de
                            <?php echo e($location->boletas); ?>

                        </span>
                    </div>
                    <div class="text-right">
                        <span class="text-xs font-semibold inline-block text-gray-600">
                            <?php echo e($location->guests()->count() > 0
                            ?round(($location->guests()->whereNotNull('attendance_door_id')->count()/$location->boletas)*100,0)
                            : '0'); ?>%


                        </span>
                    </div>
                </div>
                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                    <div style="width: <?php echo e($location->guests()->count() > 0 ?round(($location->guests()->whereNotNull('attendance_door_id')->count()/$location->boletas)*100,0) : '0'); ?>%"
                        class="
                  shadow-none
                  flex flex-col
                  text-center
                  whitespace-nowrap
                  text-white
                  justify-center
                  bg-green-500
                "></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
    <?php elseif($view == 'attendance2'): ?>
    <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['icon' => 'fab fa-searchengin','title' => 'Asistencia por coordinación']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <div class="grid grid-cols-3 gap-5">
            <?php $__currentLoopData = $coordinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coordination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative pt-1 hover:border-gray-400 border-white border border-solid p-1 rounded">
                <div class="flex mb-2 items-center justify-between">
                    <div>
                        <span class="
                    text-xs
                    font-semibold
                    inline-block
                    py-1
                    px-2
                    uppercase
                    rounded-full
                    text-gray-600
                    bg-gray-200
                    w-40
                    text-center
                  ">
                            <?php echo e($coordination->name); ?>

                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xs font-semibold inline-block text-gray-600">
                            <?php echo e($coordination->count_pending_guests()); ?> de
                            <?php echo e($coordination->count_guests()); ?>

                        </span>
                    </div>
                    <div class="text-right">
                        <span class="text-xs font-semibold inline-block text-gray-600">
                            <?php echo e($coordination->count_guests() > 0
                            ?round(($coordination->count_pending_guests()/$coordination->count_guests())*100,0)
                            : '0'); ?>%


                        </span>
                    </div>
                </div>
                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                    <div style="width: <?php echo e($coordination->count_guests() > 0 ?round(($coordination->count_pending_guests()/$coordination->count_guests())*100,0) : '0'); ?>%"
                        class="
                  shadow-none
                  flex flex-col
                  text-center
                  whitespace-nowrap
                  text-white
                  justify-center
                  bg-green-500
                "></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
    <?php elseif($view == 'count'): ?>
    <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['icon' => 'fab fa-searchengin','title' => 'Preliminar de votaciones por sede']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <?php if(Auth::user()->hasPermission('Jurídico') || Auth::user()->hasPermission('Administrator') ||
        Auth::user()->hasPermission('Jurídico Global')): ?>

        <div class="relative pt-1 hover:border-gray-400 border-white border border-solid p-1 rounded">
            <div class="flex mb-2 items-center justify-between">
                <div>
                    <span class="
                text-xs
                font-semibold
                inline-block
                py-1
                px-2
                uppercase
                rounded-full
                font-bold
                bg-<?php echo e($event->locations()->sum('si') == 0 && $event->locations()->sum('no') == 0 ? 'gray-200 text-gray-600' : ($event->locations()->sum('si') > ($event->locations()->sum('no') + $event->locations()->sum('nulos')) ? 'green-600 text-white':'red-500 text-white')); ?>

              ">
                        GLOBAL
                    </span>
                </div>
                <div class="text-left">
                    <span class="text-base font-bold inline-block text-gray-600">
                        Si
                        <?php echo e(round(($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos'))
                        > 0 ?
                        ($event->locations()->sum('si')/($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos')))*100:0,0)
                        ?? 0); ?>% (<?php echo e($event->locations()->sum('si')); ?>)
                    </span>
                </div>
                <div class="text-left">
                    <span class="text-xs font-semibold inline-block text-gray-600">
                        No
                        <?php echo e(round(($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos'))
                        > 0 ?
                        ($event->locations()->sum('no')/($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos')))*100:0,0)
                        ?? 0); ?>% (<?php echo e($event->locations()->sum('no')); ?>)
                    </span>
                </div>
                <div class="text-left">
                    <span class="text-xs font-semibold inline-block text-gray-600">
                        Nulo
                        <?php echo e(round(($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos'))
                        > 0 ?
                        ($event->locations()->sum('nulos')/($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos')))*100:0,0)
                        ?? 0); ?>% (<?php echo e($event->locations()->sum('nulos')); ?>)
                    </span>
                </div>
                <div class="text-left">
                    <span class="text-xs font-semibold inline-block text-gray-600">
                        No votó <?php echo e($event->locations()->sum('anulados')); ?>

                    </span>
                </div>
            </div>
            <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                <div style="width: <?php echo e(round(($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos')) > 0 ?
                    ($event->locations()->sum('si')/($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos')))*100:0,0) ?? 0); ?>%"
                    class="
              shadow-none
              flex flex-col
              text-center
              whitespace-nowrap
              text-white
              justify-center
              bg-green-500
            "></div>
                <div style="width: <?php echo e(round(($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos')) > 0 ?
                    ($event->locations()->sum('no')/($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos')))*100:0,0) ?? 0); ?>%"
                    class="
          shadow-none
          flex flex-col
          text-center
          whitespace-nowrap
          text-white
          justify-center
          bg-red-500
        "></div>
                <div style="width: <?php echo e(round(($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos')) > 0 ?
            ($event->locations()->sum('nulos')/($event->locations()->sum('si')+$event->locations()->sum('no')+$event->locations()->sum('nulos')))*100:0,0) ?? 0); ?>%"
                    class="
  shadow-none
  flex flex-col
  text-center
  whitespace-nowrap
  text-white
  justify-center
  bg-gray-400
"></div>
            </div>
        </div>
        <?php endif; ?>
        <div class="grid grid-cols-3 gap-5">
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative pt-1 hover:border-gray-400 border-white border border-solid p-1 rounded">
                <div class="flex mb-2 items-center justify-between">
                    <div>
                        <span class="
                    text-xs
                    font-semibold
                    inline-block
                    py-1
                    px-2
                    uppercase
                    rounded-full
                    font-bold
                    bg-<?php echo e($location->si == 0 && $location->no == 0 ? 'gray-200 text-gray-600' : ($location->si > ($location->no + $location->nulos) ? 'green-600 text-white':'red-500 text-white')); ?>

                  ">
                            Sede <?php echo e($location->name); ?>

                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-base font-bold inline-block text-gray-600">
                            Si <?php echo e(round(($location->si+$location->no+$location->nulos) > 0 ?
                            ($location->si/($location->si+$location->no+$location->nulos))*100:0,0) ?? 0); ?>%
                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xs font-semibold inline-block text-gray-600">
                            No <?php echo e(round(($location->si+$location->no+$location->nulos) > 0 ?
                            ($location->no/($location->si+$location->no+$location->nulos))*100:0,0) ?? 0); ?>%
                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xs font-semibold inline-block text-gray-600">
                            Nulo <?php echo e(round(($location->si+$location->no+$location->nulos) > 0 ?
                            ($location->nulos/($location->si+$location->no+$location->nulos))*100:0,0) ?? 0); ?>%
                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xs font-semibold inline-block text-gray-600">
                            No votó <?php echo e($location->anulados); ?>

                        </span>
                    </div>
                </div>
                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                    <div style="width: <?php echo e(round(($location->si+$location->no+$location->nulos) > 0 ?
                        ($location->si/($location->si+$location->no+$location->nulos))*100:0,0) ?? 0); ?>%" class="
                  shadow-none
                  flex flex-col
                  text-center
                  whitespace-nowrap
                  text-white
                  justify-center
                  bg-green-500
                "></div>
                    <div style="width: <?php echo e(round(($location->si+$location->no+$location->nulos) > 0 ?
                        ($location->no/($location->si+$location->no+$location->nulos))*100:0,0) ?? 0); ?>%" class="
              shadow-none
              flex flex-col
              text-center
              whitespace-nowrap
              text-white
              justify-center
              bg-red-500
            "></div>
                    <div style="width: <?php echo e(round(($location->si+$location->no+$location->nulos) > 0 ?
                ($location->nulos/($location->si+$location->no+$location->nulos))*100:0,0) ?? 0); ?>%" class="
      shadow-none
      flex flex-col
      text-center
      whitespace-nowrap
      text-white
      justify-center
      bg-gray-400
    "></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
    <?php elseif($view == 'count2'): ?>
    <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['icon' => 'fab fa-searchengin','title' => 'Preliminar de votaciones por coordinación']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <div class="grid grid-cols-3 gap-5">
            <?php $__currentLoopData = $coordinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coordination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative pt-1 hover:border-gray-400 border-white border border-solid p-1 rounded">
                <div class="flex mb-2 items-center justify-between">
                    <div>
                        <span class="
                    text-xl
                    font-semibold
                    inline-block
                    py-1
                    px-2
                    uppercase
                    rounded-full
                    font-bold
                    w-64
                    text-center
                    bg-<?php echo e($coordination->doors()->sum('si') == 0 && $coordination->doors()->sum('no') == 0 ? 'gray-200 text-gray-600' : ($coordination->doors()->sum('si') > ($coordination->doors()->sum('no') + $coordination->doors()->sum('nulos')) ? 'green-600 text-white':'red-500 text-white')); ?>

                  ">
                            <?php echo e($coordination->name); ?>

                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xl font-bold inline-block text-gray-600">
                            Si
                            <?php echo e(round(($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos'))
                            > 0 ?
                            ($coordination->doors()->sum('si')/($coordination->doors()->sum('no')+$coordination->doors()->sum('si')+$coordination->doors()->sum('nulos')))*100:0,0)
                            ?? 0); ?>%
                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xl font-semibold inline-block text-gray-600">
                            No
                            <?php echo e(round(($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos'))
                            > 0 ?
                            ($coordination->doors()->sum('no')/($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos')))*100:0,0)
                            ?? 0); ?>%
                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xl font-semibold inline-block text-gray-600">
                            Nulo
                            <?php echo e(round(($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos'))
                            > 0 ?
                            ($coordination->doors()->sum('nulos')/($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos')))*100:0,0)
                            ?? 0); ?>%
                        </span>
                    </div>
                </div>
                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                    <div style="width: <?php echo e(round(($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos')) > 0 ?
                        ($coordination->doors()->sum('si')/($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos')))*100:0,0) ?? 0); ?>%"
                        class="
                  shadow-none
                  flex flex-col
                  text-center
                  whitespace-nowrap
                  text-white
                  justify-center
                  bg-green-500
                "></div>
                    <div style="width: <?php echo e(round(($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos')) > 0 ?
                        ($coordination->doors()->sum('no')/($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos')))*100:0,0) ?? 0); ?>%"
                        class="
              shadow-none
              flex flex-col
              text-center
              whitespace-nowrap
              text-white
              justify-center
              bg-red-500
            "></div>
                    <div style="width: <?php echo e(round(($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos')) > 0 ?
                ($coordination->doors()->sum('nulos')/($coordination->doors()->sum('si')+$coordination->doors()->sum('no')+$coordination->doors()->sum('nulos')))*100:0,0) ?? 0); ?>%"
                        class="
      shadow-none
      flex flex-col
      text-center
      whitespace-nowrap
      text-white
      justify-center
      bg-gray-400
    "></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Card::class, ['icon' => 'fab fa-searchengin','title' => 'Preliminar de votaciones por sección']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <div class="grid grid-cols-3 gap-5">
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $location->doors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $door): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative pt-1 hover:border-gray-400 border-white border border-solid p-1 rounded">
                <div class="flex mb-2 items-center justify-between">
                    <div>
                        <span class="
                    text-lg
                    font-semibold
                    inline-block
                    py-1
                    px-2
                    uppercase
                    rounded-full
                    font-bold
                    w-40
                    text-center
                    bg-<?php echo e($door->si == 0 && $door->no == 0 ? 'gray-200 text-gray-600' : ($door->si > ($door->no + $door->nulos) ? 'green-600 text-white':'red-500 text-white')); ?>

                  ">
                            Sección <?php echo e($door->name); ?>

                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xl font-bold inline-block text-gray-600">
                            Si
                            <?php echo e(round(($door->si+$door->no+$door->nulos)
                            > 0 ?
                            ($door->si/($door->no+$door->si+$door->nulos))*100:0,0)
                            ?? 0); ?>%
                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xl font-semibold inline-block text-gray-600">
                            No
                            <?php echo e(round(($door->si+$door->no+$door->nulos)
                            > 0 ?
                            ($door->no/($door->si+$door->no+$door->nulos))*100:0,0)
                            ?? 0); ?>%
                        </span>
                    </div>
                    <div class="text-left">
                        <span class="text-xl font-semibold inline-block text-gray-600">
                            Nulo
                            <?php echo e(round(($door->si+$door->no+$door->nulos)
                            > 0 ?
                            ($door->nulos/($door->si+$door->no+$door->nulos))*100:0,0)
                            ?? 0); ?>%
                        </span>
                    </div>
                </div>
                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                    <div style="width: <?php echo e(round(($door->si+$door->no+$door->nulos) > 0 ?
                        ($door->si/($door->si+$door->no+$door->nulos))*100:0,0) ?? 0); ?>%" class="
                  shadow-none
                  flex flex-col
                  text-center
                  whitespace-nowrap
                  text-white
                  justify-center
                  bg-green-500
                "></div>
                    <div style="width: <?php echo e(round(($door->si+$door->no+$door->nulos) > 0 ?
                        ($door->no/($door->si+$door->no+$door->nulos))*100:0,0) ?? 0); ?>%" class="
              shadow-none
              flex flex-col
              text-center
              whitespace-nowrap
              text-white
              justify-center
              bg-red-500
            "></div>
                    <div style="width: <?php echo e(round(($door->si+$door->no+$door->nulos) > 0 ?
                ($door->nulos/($door->si+$door->no+$door->nulos))*100:0,0) ?? 0); ?>%" class="
      shadow-none
      flex flex-col
      text-center
      whitespace-nowrap
      text-white
      justify-center
      bg-gray-400
    "></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>
    <?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/event/legitimation/reports/index.blade.php ENDPATH**/ ?>