<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Sistema de legitimación - Siconecta</title>
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/vendor/fontawesome/css/all.min.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
    <script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.js')); ?>" defer></script>
</head>

<body class="bg-gray-100" style="overflow: hidden">


    <?php echo e($slot); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('js/sweetalerts.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\consejo\resources\views/layouts/attendance.blade.php ENDPATH**/ ?>