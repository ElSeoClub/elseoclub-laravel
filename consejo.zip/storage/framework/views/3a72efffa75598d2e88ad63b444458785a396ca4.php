<div>
    <div>
        <div class="grid grid-cols-12 grid-gap-5 mb-5">
            <div class="col-span-9"></div>
            <div class="col-span-3">
                <?php if (isset($component)) { $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Search::class, []); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65)): ?>
<?php $component = $__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65; ?>
<?php unset($__componentOriginal9c20e82a484d0dd8436a68d661ca92fd15770a65); ?>
<?php endif; ?>
            </div>
        </div>
        <div wire:loading.remove wire:target="search">
            <?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, []); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('thead', null, []); ?> 
                    <th class="text-left px-3 py-2"><?php echo e(__('Legitimación')); ?></th>
                    <th class="text-left px-3 py-2 w-44"><?php echo e(__('Fecha de inicio')); ?></th>
                    <th class="text-left px-3 py-2 w-44"><?php echo e(__('Fecha de cierre')); ?></th>
                    <th class="w-4"></th>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('tbody', null, []); ?> 
                    <?php if(count($legitimations) == 0): ?>
                    <tr>
                        <td colspan="4" class="text-center font-bold text-lg p-2 text-red-600">
                            <?php echo e(__('No record was found.')); ?>

                        </td>
                    </tr>
                    <?php else: ?>

                    <?php $__currentLoopData = $legitimations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $legitimation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-left p-3">
                            <i
                                class="fas fa-lock<?php echo e($legitimation->status == 'open'? '-open':''); ?> text-yellow-500 mr-2"></i>
                            <a href="<?php echo e(route('legitimation.show',['event' => $legitimation->id])); ?>"
                                class="text-red-600 font-bold hover:text-red-800">

                                <?php echo e($legitimation->name); ?>

                            </a>
                        </td>
                        <td class="text-left p-3">
                            <?php echo e($legitimation->start_date->format('d/m/Y')); ?>

                        </td>
                        <td class="text-left p-3">
                            <?php echo e($legitimation->end_date->format('d/m/Y')); ?>

                        </td>

                        <td class="text-left p-3">
                            <?php if(Auth::user()->hasPermission('Administrator')): ?>
                            <i class="fas fa-trash text-red-600 hover:text-red-700 cursor-pointer"
                                wire:click="delete(<?php echo e($legitimation->id); ?>)"></i>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>

                 <?php $__env->slot('pagination', null, []); ?> 
                    <?php echo e($legitimations->links()); ?>

                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?>

        </div>
        <div wire:loading.delay wire:loading.inline wire:target="search">
            <?php if (isset($component)) { $__componentOriginald7e0e4ad27203c9b101a92eaeb2f1d5c375c9724 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\LoadingTable::class, ['rows' => '10','columns' => '3']); ?>
<?php $component->withName('loading-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald7e0e4ad27203c9b101a92eaeb2f1d5c375c9724)): ?>
<?php $component = $__componentOriginald7e0e4ad27203c9b101a92eaeb2f1d5c375c9724; ?>
<?php unset($__componentOriginald7e0e4ad27203c9b101a92eaeb2f1d5c375c9724); ?>
<?php endif; ?>
        </div>
    </div>
    <?php if(Auth::user()->hasPermission('Administrator')): ?>
    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['icon' => 'fas fa-plus','class' => 'mt-5','color' => 'green','href' => route('legitimation.create')]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Crear nueva
        legitimación <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\consejo\resources\views/livewire/event/legitimation/table.blade.php ENDPATH**/ ?>