<?php if (isset($component)) { $__componentOriginalecc87447b355f25836aee690249287dacd69bf5a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AttendanceLayout::class, []); ?>
<?php $component->withName('attendance-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="flex bg-red-500 p-2 text-center text-white font-bold border-b-4 border-yellow-400">
        <div class="px-10">
            <a href="<?php echo e(route('legitimation.attendance',['event' => $door->location->event->id])); ?>"><img
                    src="<?php echo e(asset('svg/siconecta-txt.svg')); ?>" style="height:40px"></a>
        </div>
        <div class="text-3xl text-center w-full h-full align-middle">
            Congreso Nacional Extraordinario XX
        </div>
    </div>
    <div class="m-6">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('event.legitimation.attendance.screen', ['door' => $door])->html();
} elseif ($_instance->childHasBeenRendered('VYrOTu8')) {
    $componentId = $_instance->getRenderedChildComponentId('VYrOTu8');
    $componentTag = $_instance->getRenderedChildComponentTagName('VYrOTu8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VYrOTu8');
} else {
    $response = \Livewire\Livewire::mount('event.legitimation.attendance.screen', ['door' => $door]);
    $html = $response->html();
    $_instance->logRenderedChild('VYrOTu8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecc87447b355f25836aee690249287dacd69bf5a)): ?>
<?php $component = $__componentOriginalecc87447b355f25836aee690249287dacd69bf5a; ?>
<?php unset($__componentOriginalecc87447b355f25836aee690249287dacd69bf5a); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\consejo\resources\views/event/legitimation/attendance/screen.blade.php ENDPATH**/ ?>