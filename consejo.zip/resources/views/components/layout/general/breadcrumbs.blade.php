<div>
    <nav class="text-black font-bold mb-5" aria-label="Breadcrumb">
        <ol class="list-none p-0 inline-flex">
            {{$slot}}
        </ol>
    </nav>
</div>