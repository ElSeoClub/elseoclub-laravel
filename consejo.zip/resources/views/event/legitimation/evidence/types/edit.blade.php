<x-general-layout>
    <x-slot name="title">Tipos de evidencia</x-slot>
    <x-layout.general.breadcrumbs>
        <x-layout.general.breadcrumb-option name="Catálogos de evidencia" arrow="true"
            :route="route('legitimation.evidence.types')" />
        <x-layout.general.breadcrumb-option name="{{$evidence->name}}" arrow="false" />
    </x-layout.general.breadcrumbs>

    @livewire('event.legitimation.evidence.types.edit', compact('evidence'))
</x-general-layout>