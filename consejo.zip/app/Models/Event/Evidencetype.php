<?php

namespace App\Models\Event;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Evidencetype extends Model
{
    use HasFactory;

    protected $guarded = [];
}
