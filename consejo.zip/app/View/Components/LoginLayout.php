<?php

namespace App\View\Components;

use Illuminate\View\Component;

class LoginLayout extends Component
{
    public function render()
    {
        return view('layouts.login');
    }
}
